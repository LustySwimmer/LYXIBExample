//
//  LYTestView.m
//  LYBridgeExample
//
//  Created by 吕师 on 16/7/8.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

#import "LYTestView.h"

@interface LYTestView ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *buttonArray;

@end

@implementation LYTestView

- (void)setTitle:(NSString *)title {
    _title = [title copy];
    self.titleLabel.text = title;
}

- (void)setImage:(UIImage *)image {
    _image = image;
    self.imageView.image = image;
}

- (void)setPromptTitle:(NSString *)promptTitle {
    _promptTitle = [promptTitle copy];
    for (UIButton *button in self.buttonArray) {
        [button setTitle:promptTitle forState:UIControlStateNormal];
    }
}

@end
