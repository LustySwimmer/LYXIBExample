//
//  LYProgressView.h
//  测试空工程
//
//  Created by Mac on 16/1/15.
//  Copyright © 2016年 吕师. All rights reserved.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE
@interface LYProgressView : UIView

/**当前进度颜色*/
@property (nonatomic,strong)IBInspectable UIColor *progressTint;
/**高亮颜色*/
@property (nonatomic,strong)IBInspectable UIColor *trackTint;
/**当前进度(0-1)*/
@property (nonatomic,assign)IBInspectable CGFloat progress;

@end
