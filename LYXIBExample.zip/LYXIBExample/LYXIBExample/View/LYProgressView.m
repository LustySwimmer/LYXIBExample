//
//  LYProgressView.m
//  测试空工程
//
//  Created by Mac on 16/1/15.
//  Copyright © 2016年 吕师. All rights reserved.
//

#import "LYProgressView.h"

@implementation LYProgressView

#pragma mark - 初始化相关
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initializeData];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self initializeData];
    }
    return self;
}
/** 初始化设置 */
- (void)initializeData {
    self.progressTint = [UIColor redColor];
    self.trackTint = [UIColor lightGrayColor];
    self.progress = 0.7;
}

#pragma mark - setter 和 getter
- (void)setProgressTint:(UIColor *)progressTint {
    _progressTint = progressTint;
    [self setNeedsDisplay];
}

- (void)setTrackTint:(UIColor *)trackTint {
    _trackTint = trackTint;
    [self setNeedsDisplay];
}
- (void)setProgress:(CGFloat)progress {
    _progress = progress;
    [self setNeedsDisplay];
}

#pragma mark - 画图

- (void)drawRect:(CGRect)rect {
    [self drawWithColor:_trackTint.CGColor rect:self.bounds];
    [self drawProgressTint];
}

- (void)drawProgressTint {
    CGColorRef color = _progressTint.CGColor;
    CGFloat width = _progress * self.bounds.size.width;
    CGFloat height = self.bounds.size.height;
    CGRect rect = CGRectMake(0, 0, width, height);
    [self drawWithColor:color rect:rect];
}

- (void)drawWithColor:(CGColorRef)color rect:(CGRect)rect {
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGFloat originX = self.bounds.origin.x;
    CGFloat originY = self.bounds.origin.y;
    CGContextBeginPath(context);
    CGContextMoveToPoint(context, originX, originY);
    CGContextAddRect(context, rect);
    CGContextSetLineWidth(context, 1.0f);
    CGContextSetFillColorWithColor(context, color);
    CGContextFillPath(context);
}

@end
